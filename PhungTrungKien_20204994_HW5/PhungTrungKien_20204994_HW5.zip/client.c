// udp client driver program 
#include <stdio.h> 
#include <strings.h> 
#include <sys/types.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h>
#include<stdlib.h> 
#include<string.h>
#define MAXLINE 1000 

// Driver code 
int main(int argc, char *argv[]) 
{
	// catch wrong input
	if(argc!=3){
		printf("Please input IP address and port number\n");
		return 0;
	}
	// ip_address : get ip from argv
	// port : get port from argv
	// buffer : data get from server
	// message: data send to server
	char *ip_address = argv[1];
	char *port_number = argv[2];
	int port = atoi(port_number);

	int sock = 0, n; 
	struct sockaddr_in serv_addr; 
	
	// Try catch false when connecting
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 

	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_port = htons(port); 
	
	// Convert IPv4 and IPv6 addresses from text to binary form 
	if(inet_pton(AF_INET, ip_address, &serv_addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 

	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
	{ 
		printf("\nConnection Failed \n"); 
		return -1; 
	} 
	// Input
	int g = 0;
	char buffer[1000];
	char message[1000];
	printf("Enter any character to start. If nothing happens, the connection failed: ");
	g = scanf("%[^\n]", message); 
	getchar();
	send(sock, message, strlen(message) , 0); 
	do {
		// Read Output
		read(sock, buffer, MAXLINE);
		puts(buffer); 

		// Input
		int g = 0;
		char buffer[100];
		char message[100];
		g = scanf("%[^\n]", message); 
		if (g == 0) break;
		getchar();
		send(sock, message, strlen(message) , 0); 
		
	}while(1);	
	// close the descriptor 
	close(sock); 
	return 0;
}
